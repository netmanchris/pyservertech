myauth = STAuth('10.101.0.31', 'public', 'private')
x =  build_socket_list(myauth, 16)

myauth2 = STAuth('10.101.0.32', 'public', 'private')
y =  build_socket_list(myauth2, 16)

